package wsbSpringBootAPI.wsbSpringBootAPI.entities;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import java.util.Date;
import java.util.Objects;
import java.util.Random;

@Document(collection = "accounts")
public class Account {



    @Id
    private String id;

    @Indexed(unique = true)
    @Field("accountNumber")
    private Integer accountNumber;
    
    @Field("transactionTs")
    private Date transactionTs;


    @Field("type")
    private String type;

    public Date getTransactionTs() {
		return transactionTs;
	}

	public void setTransactionTs(Date transactionTs) {
		this.transactionTs = transactionTs;
	}

	@Field("amount")
    private Double amount;


    public Integer getAccountNumber() {
        return accountNumber;
    }

    public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	
    public void setAccountNumber(Integer accountNumber) {
        if(accountNumber != null) {
            this.accountNumber = accountNumber;
        } else {
            Random random = new Random(234);
            this.accountNumber = random.nextInt();
        }
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String toString() {
            String presentation = String.format(":::ACCOUNT | ID: %s | ACCOUNT NUMBER: %d | ACCOUNT TYPE: %s | BALANCE: %f :::", id, accountNumber, type, amount);
            return presentation;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Account)) return false;
        Account account = (Account) o;
        return id.equals(account.id) &&
                accountNumber.equals(account.accountNumber) &&
                type.equals(account.type) &&
               amount.equals(account.amount);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, accountNumber, type, amount);
    }
}
