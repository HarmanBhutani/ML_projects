package wsbSpringBootAPI.wsbSpringBootAPI.controller;

import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Date;

public class Welcome {

    private String status;

    private String java;

    private String date;

    private String author;

    private String readme;

    public Welcome() {
        this.status = "RUNNING";
        this.java = "v11";
        this.date = new Date().toString();
        this.author = "byteharman0101@gmail.com";
        try {
            File file = ResourceUtils.getFile("classpath:static/Readme.txt");
            this.readme = new String(Files.readAllBytes(file.toPath()));
        } catch (IOException ioException) {
            ioException.printStackTrace();
                  
                 
        }
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getJava() {
        return java;
    }

    public void setJava(String java) {
        this.java = java;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getReadme() {
        return readme;
    }

    public void setReadme(String readme) {
        this.readme = readme;
    }
}
