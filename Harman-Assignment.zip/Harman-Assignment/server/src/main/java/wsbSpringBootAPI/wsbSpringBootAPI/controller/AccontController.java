package wsbSpringBootAPI.wsbSpringBootAPI.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import wsbSpringBootAPI.wsbSpringBootAPI.entities.Account;
import wsbSpringBootAPI.wsbSpringBootAPI.service.BankService;
import wsbSpringBootAPI.wsbSpringBootAPI.service.Transfer;
import wsbSpringBootAPI.wsbSpringBootAPI.viewObjects.FullAccountInfo;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("")
public class AccontController {

    @Autowired
    private BankService bankService;


    @GetMapping("/{accountNumber}")
    public Account getOneAccount(@PathVariable String id) {
        Account account = bankService.getAccount(id); 
        return account;
    }

    @PutMapping("/accountNumber = {accountNumber} & start={transactionTs)&end={transactionTs}")
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public Account updateAccount(@PathVariable String id, @RequestBody Account accountToUpdate, @RequestBody Account transactionTs ) {
        Account account = bankService.updateAccount(id, accountToUpdate,transactionTs);
        return account;

    }
 

    @PutMapping("/accountNumber = {accountNumber} & type = {type}")
    @ResponseStatus(code = HttpStatus.ACCEPTED)
    public void transferFunds(@RequestBody Transfer transfer) {
            bankService.transferFunds(transfer);
    }


}
