package wsbSpringBootAPI.wsbSpringBootAPI.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import wsbSpringBootAPI.wsbSpringBootAPI.entities.Account;
import wsbSpringBootAPI.wsbSpringBootAPI.exception.CreationException;
import wsbSpringBootAPI.wsbSpringBootAPI.exception.ResourceNotFound;
import wsbSpringBootAPI.wsbSpringBootAPI.exception.TransferException;
import wsbSpringBootAPI.wsbSpringBootAPI.repository.AccountsRepository;
import wsbSpringBootAPI.wsbSpringBootAPI.viewObjects.FullAccountInfo;
import java.util.*;

@Service
public class BankService {

    @Autowired
    private AccountsRepository accountsRepository;



    public List<Account> getAllAccounts() {
        return accountsRepository.findAll();
    }

    public Account getAccount(String id) {
        try {
            Optional<Account> accounts = accountsRepository.findById(id);
            Account account = accounts.get();
            return account;
        } catch (NoSuchElementException noSuchElementException) {
            throw new ResourceNotFound("Account with a given ID does not exist: " + id);
        }
    }

    public Account updateAccount(String id, Account accountToUpdate, Account transactionTs) {
        try {
            Optional<Account> accounts = accountsRepository.findById(id);
            Account account = accounts.get();
            account.setAccountNumber(accountToUpdate.getAccountNumber());
            account.setType(accountToUpdate.getType());
            account.setAmount(accountToUpdate.getAmount());
            return accountsRepository.save(account);
        } catch (NoSuchElementException noSuchElementException) {
            throw new ResourceNotFound("Account with a given ID does not exist: " + id);
        }
    }


    public void transferFunds(Transfer transfer) {
        if(transfer.getAmount() <= 0) {
            throw new TransferException("Cannot perform transfer for an amount lower than 0.00");
        }
        try {
            if (!transfer.getFromAccount().equals(transfer.getToAccount())) {
                Optional<Account> accounts = accountsRepository.findAccountByAccountNumber(transfer.getFromAccount());
                Account from = accounts.get();
                accounts = accountsRepository.findAccountByAccountNumber(transfer.getToAccount());
                Account to = accounts.get();
                if (from.getAmount().compareTo(transfer.getAmount()) >= 0) {
                    accountsRepository.save(from);
                    accountsRepository.save(to);
                } else {
                    throw new TransferException(String.format("Insufficient funds on origin account: %s Current balance: %s, Requested amount %s", from.getAccountNumber(), from.getAmount(), transfer.getAmount()));
                }

            } else {
                throw new TransferException("Transfer accounts must be different. Requested fromAccount " + transfer.getFromAccount() + " Requested toAccount: " + transfer.getToAccount());
            }
        } catch (NullPointerException nullPointerException) {
            throw new ResourceNotFound(String.format("At least on of the accounts with the given account numbers does not exist: %d, %d", transfer.getFromAccount(), transfer.getToAccount()));
        } catch (NoSuchElementException noSuchElementException) {
            throw new ResourceNotFound(String.format("At least on of the accounts with the given account numbers does not exist: %d, %d", transfer.getFromAccount(), transfer.getToAccount()));
        }
    }
}
