package wsbSpringBootAPI.wsbSpringBootAPI.viewObjects;

import wsbSpringBootAPI.wsbSpringBootAPI.entities.Account;

import java.util.Set;

public class FullAccountInfo {

    private Account account;


    public Account getAccount() {
        return account;
    }

    public void setAccount(Account account) {
        this.account = account;
    }


}
